﻿using Microsoft.AspNetCore.Mvc;
using productmanagement.wwwroot.services;


namespace productmanagement.Controllers
{
    public class ProductController : Controller
    {
        private readonly Iproductservice _productService;
        public ProductController(Iprod        uctservice productservice)
        {
            _productService = productservice;
        }
        public IActionResult Index()
        {
            var product = _productService.GetAllProducts();
            return View(product);
        }
        public IActionResult Details(int id)
        {
            var product = _productService.GetProductById(id);
            if (product == null)
                return NotFound();
            return View(product);
        }
    }
}