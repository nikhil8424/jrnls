﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Projectmanagement.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;

        public decimal Price { get; set; }
        public string Category { get; set; } = string.Empty;
        public int StockQuantity { get; set; }
        public string ImgURL { get; set; } = string.Empty;
        public DateTime CreateDate {get; set;}
        public bool IsActice { get; set; } = true;



    }
}
